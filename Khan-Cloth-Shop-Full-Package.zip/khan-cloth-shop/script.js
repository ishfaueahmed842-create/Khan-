// ==============================
// Photo Upload + Preview
// ==============================
function previewImage(input, imgId, areaId) {
  const file = input.files[0];
  if (!file) return;

  // Size check (max 5MB)
  if (file.size > 5 * 1024 * 1024) {
    alert("Image size should be less than 5MB");
    return;
  }

  const reader = new FileReader();
  reader.onload = function (e) {
    const img = document.getElementById(imgId);
    img.src = e.target.result;
    document.getElementById(areaId).classList.add("has-image");

    // Save to localStorage so it stays after refresh
    try {
      localStorage.setItem(imgId, e.target.result);
    } catch (err) {
      console.warn("Could not save image to localStorage (maybe too large)");
    }
  };
  reader.readAsDataURL(file);
}

// Restore images from localStorage on page load
window.addEventListener("load", function () {
  ["preview1", "preview2"].forEach(function (id) {
    const saved = localStorage.getItem(id);
    if (saved) {
      const img = document.getElementById(id);
      if (img) {
        img.src = saved;
        img.parentElement.classList.add("has-image");
      }
    }
  });
});

// ==============================
// Mobile Menu Toggle
// ==============================
function toggleMenu() {
  const menu = document.getElementById("mobileMenu");
  menu.classList.toggle("open");
}

// ==============================
// Order Now → WhatsApp
// ==============================
function orderNow(productName, price) {
  // ← Apna WhatsApp number yahan likho (92 se start)
  const phone = "92XXXXXXXXXX";

  const message = encodeURIComponent(
    `Assalam o Alaikum!\n\n` +
    `Main *${productName}* order karna chahta/chahti hoon.\n` +
    `Price: Rs. ${price.toLocaleString()}\n\n` +
    `Please confirm availability. Shukriya!`
  );

  window.open(`https://wa.me/${phone}?text=${message}`, "_blank");
}

// Close menu when clicking outside
document.addEventListener("click", function (e) {
  const menu = document.getElementById("mobileMenu");
  const btn = document.querySelector(".menu-btn");
  if (menu.classList.contains("open") && !menu.contains(e.target) && !btn.contains(e.target)) {
    menu.classList.remove("open");
  }
});
