# Khan Cloth Shop – Full Package

Simple, mobile-friendly product listing website with **Photo Upload** feature.

## Features

- Clean modern design (same style as your screenshot)
- Photo Upload button on every product card
- Image preview + saves in browser (localStorage)
- Order Now button opens WhatsApp with pre-filled message
- Floating WhatsApp button
- Mobile responsive
- Sticky header + simple menu

## How to use

### 1. Local testing
1. Unzip this folder
2. Open `index.html` in any browser (Chrome / Edge recommended)

### 2. GitHub Pages pe deploy
1. Create a new repository on GitHub (e.g. `khan-cloth-shop`)
2. Upload all files (`index.html`, `style.css`, `script.js`)
3. Go to **Settings → Pages**
4. Source = Deploy from a branch → `main` → `/ (root)`
5. Save. Your site will be live at:  
   `https://YOUR-USERNAME.github.io/khan-cloth-shop/`

### 3. Important – WhatsApp Number change karein
`script.js` file open karein aur yeh line dhundein:

```js
const phone = "92XXXXXXXXXX";
```

Apna real WhatsApp number daal dein (example: `923001234567`)

Same number `index.html` ke floating WhatsApp button mein bhi change kar dein.

## Photo Upload kaise kaam karta hai?

- Har product pe **📷 Photo Upload** button hai
- Image select karte hi turant preview aa jati hai
- Browser refresh karne pe bhi image rahegi (localStorage)
- Permanent online storage chahiye to Cloudinary / ImgBB lagana padega (mujhse pooch sakte ho)

## Extra Products add karna

`index.html` mein koi bhi product card copy-paste karein aur IDs change kar dein (`preview3`, `imgArea3`, `file3` etc.)

---

Made for Khan Cloth Shop
